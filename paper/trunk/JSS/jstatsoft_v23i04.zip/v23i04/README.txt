Source code for
  Arne Henningsen, Jeff D. Hamann
  systemfit: A Package for Estimating Systems of Simultaneous Equations in R
  Journal of Statistical Software, 23(4), December 2007

systemfit_1.0-1.tar.gz: R source package
v23i04.zip:             R example scripts from the paper
